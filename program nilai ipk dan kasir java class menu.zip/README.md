1. URL BLOG untuk Kasir Toko Cupcake 
https://muchib.kreatif.win/2019/12/aplikasi-kasir-toko-java-swing-gui-pemrograman.html?m=1
2. URL BLOG untuk Data nilai dan IPK Mahasiswa
https://muchib.kreatif.win/2019/12/aplikasi-menghitung-nilai-dan-ipk-java-swing-gui.html
3. URL BLOG untuk membuat menu kasir dan hitung ipk
https://muchib.kreatif.win/2019/12/pemrograman-java-gui-data-programmer-menu-list.html?m=1 
